import { AbstractType, Component, OnInit } from '@angular/core';
import { VehicleService } from '../services/vehicle.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { forkJoin} from 'rxjs';
import { Vehcile } from '../models/Vehicle';
import { SaveVehicle } from '../models/SaveVehicle';
import { Contact } from '../models/Contact';
//import 'rxjs/Observable/forkJoin';

@Component({
  selector: 'app-vehilce-form',
  templateUrl: './vehilce-form.component.html',
  styleUrls: ['./vehilce-form.component.css']
})
export class VehilceFormComponent implements OnInit {
  makes: any;
  models: any;
  features: any = [];
  vehicle: SaveVehicle = {
    makeId: 0,
    modelId: 0,
    contact: {name: '', email: '', phone: ''},
    features: [],
    isRegistered: false,
    lastUpdated: ''
  };
  vehicleId: number;

  constructor(private vehicleService: VehicleService,
              private router: Router,
              private activatedRoute: ActivatedRoute) { 
                this.activatedRoute.params.subscribe(params => {
                  this.vehicleId = +params['id'];
                });
              }

  ngOnInit() {
    let sources = [this.vehicleService.getMakes(), this.vehicleService.getFeatures()];
    if(this.vehicleId){
      sources.push(this.vehicleService.getVehicleDetails(this.vehicleId));
    }
    forkJoin(sources).subscribe(data => {
      this.makes = data[0];
      this.features = data[1];
      if(this.vehicleId)
      {
        this.setVehicleDetails(data[2] as Vehcile);
        this.loadModels();
      }
    });
  }

  setVehicleDetails(v: Vehcile){
    this.vehicle.makeId = v.make.id;
    this.vehicle.modelId = v.model.id;
    this.vehicle.contact = v.contact;
    this.vehicle.isRegistered = v.isRegistered;
    this.vehicle.lastUpdated = v.lastUpdated;

    for(let feature of v.features){
      this.vehicle.features.push(feature.id);
    }
  }

  onMakeSelected() {
    this.loadModels();
    delete this.vehicle.modelId;
  }

  loadModels()
  {    
    let selectedMake = this.makes.find(x => x.id === this.vehicle.makeId);
    this.models = (selectedMake) ? selectedMake.models : [];
    console.log(this.models);
  }

  FeatureSelection(featureId, obj){
    if(obj.target.checked){
      if(this.vehicle.features)
      {
        this.vehicle.features.push(featureId)
      }
      else{
        this.vehicle.features = [featureId];
      }
    }
    else{
      let index = this.vehicle.features.indexOf(featureId);
      if(index >= 0)
      {
        this.vehicle.features.splice(index, 1);
      }
    }
  }

  submit(){
    this.vehicleService.createVehicle(this.vehicle).subscribe((data) => {
      console.log(data);
    })
  }

  Delete(){
    this.vehicleService.deleteVehicle(this.vehicleId);
  }
}
