import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehilceFormComponent } from './vehilce-form.component';

describe('VehilceFormComponent', () => {
  let component: VehilceFormComponent;
  let fixture: ComponentFixture<VehilceFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehilceFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehilceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
