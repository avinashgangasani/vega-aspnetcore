import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class VehicleService {

  constructor(private _http: HttpClient) { }

  getMakes(){
    return this._http.get('/api/makes');
  }
  getFeatures(){
    return this._http.get('/api/features');
  }

  createVehicle(vehicle)
  {
    return this._http.post('/api/vehicles', vehicle);
  }

  getVehicleDetails(id){
    return this._http.get(`/api/vehicles/${id}`);
  }

  deleteVehicle(id){
    return this._http.delete(`/api/vehicles/${id}`);
  }

  getAllVehicles(filter){

    if(filter)
    {
      let propertyArray = [];
      for(let property in filter){
        propertyArray.push(`${property}=${filter[property]}`);
      }
      let queryString=propertyArray.join('&');
      console.log("queryString", queryString);
      return this._http.get(`/api/vehicles?${queryString}`);
    }
    else{
      return this._http.get(`/api/vehicles`);
    }
  }
}
