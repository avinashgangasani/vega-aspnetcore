export interface KeyValuePair
{
    id: number,
    name: string
}