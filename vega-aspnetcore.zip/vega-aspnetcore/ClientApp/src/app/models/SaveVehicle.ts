import { Contact } from "./Contact";

export interface SaveVehicle{
    makeId: number,
    modelId: number,
    contact: Contact,
    lastUpdated: string,
    features: number[],
    isRegistered: boolean
}