using System.Threading.Tasks;

namespace vega_aspnetcore.Persistence
{
    public interface IUnitOfWork
    {
         Task CompletedAsync();
    }
}