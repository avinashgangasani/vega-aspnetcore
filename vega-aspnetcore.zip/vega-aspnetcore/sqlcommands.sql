use Vega

select * from Vega.dbo.Makes;

select * from Vega.dbo.Models;

select * from Vega.dbo.Features;

select * from Vega.dbo.Vehicles;

select * from Vega.dbo.VehicleFeatures where VehicleId = 5;