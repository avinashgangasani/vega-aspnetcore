using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using vega_aspnetcore.Controllers.Resources;
using vega_aspnetcore.Core.Models;

namespace vega_aspnetcore.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //Domain to API Resource
            CreateMap<Make, MakeResource>();
            CreateMap<Make, KeyValuePairResource>();
            CreateMap<Model, KeyValuePairResource>();
            CreateMap<Feature, KeyValuePairResource>();
            CreateMap<Vehicle, SaveVehicleResource>()
            .ForMember(vr => vr.Contact, o => o.MapFrom(v => new ContactResource { Name = v.ContactName, Phone = v.ContactPhone, Email = v.ContactEmail }))
            .ForMember(vr => vr.Features, o => o.MapFrom(v => v.VehicleFeatures.Select(x => x.FeatureId)));
            CreateMap<Vehicle, VehicleResource>()
            .ForMember(vr => vr.Contact, o => o.MapFrom(v => new ContactResource { Name = v.ContactName, Phone = v.ContactPhone, Email = v.ContactEmail }))
            .ForMember(vr => vr.Features, o => o.MapFrom(v => v.VehicleFeatures.Select(x => new KeyValuePairResource { Id = x.Feature.Id, Name = x.Feature.Name })))
            .ForMember(vr => vr.Model, o => o.MapFrom(v => new KeyValuePairResource { Id = v.Model.Id, Name = v.Model.Name }))
            .ForMember(vr => vr.Make, o => o.MapFrom(o => new MakeResource { Id = o.Model.Make.Id, Name = o.Model.Make.Name }));

            //API Resource to Domain
            CreateMap<SaveVehicleResource, Vehicle>()
            .ForMember(v => v.Id, o => o.Ignore())
            .ForMember(v => v.ContactName, o => o.MapFrom(vr => vr.Contact.Name))
            .ForMember(v => v.ContactPhone, o => o.MapFrom(vr => vr.Contact.Phone))
            .ForMember(v => v.ContactEmail, o => o.MapFrom(vr => vr.Contact.Email))
            .ForMember(v => v.VehicleFeatures, o => o.MapFrom(vr => vr.Features.Select(id => new VehicleFeature { FeatureId = id })))
            .AfterMap((vr, v) =>
            {
                //Remove unselected features
                var removedFeatures = v.VehicleFeatures.Where(x => !vr.Features.Contains(x.FeatureId)).ToList();
                foreach (var removedFeature in removedFeatures)
                {
                    v.VehicleFeatures.Remove(removedFeature);
                }

                //Add newly selected features
                var addedFeatures = vr.Features.Where(id => !v.VehicleFeatures.Any(x => x.FeatureId == id)).Select(id => new VehicleFeature { FeatureId = id }).ToList();
                foreach (var addedFeature in addedFeatures)
                {
                    v.VehicleFeatures.Add(addedFeature);
                }
            });
            CreateMap<FilterResource, Filter>();
        }
    }
}