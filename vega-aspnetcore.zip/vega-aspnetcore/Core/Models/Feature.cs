using System.ComponentModel.DataAnnotations.Schema;
namespace vega_aspnetcore.Core.Models
{
    [Table("Features")]
    public class Feature
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}