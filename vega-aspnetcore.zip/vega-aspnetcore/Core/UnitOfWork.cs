using System.Threading.Tasks;

namespace vega_aspnetcore.Persistence.Core
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly VegaDBContext context;
        public UnitOfWork(VegaDBContext context)
        {
            this.context = context;
        }
        public async Task CompletedAsync()
        {
            await context.SaveChangesAsync();
        }
    }
}