using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using vega_aspnetcore.Core.Models;

namespace vega_aspnetcore.Persistence.Core
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly VegaDBContext context;
        public VehicleRepository(VegaDBContext context)
        {
            this.context = context;

        }
        public async Task<Vehicle> GetVehicleById(int Id, bool getRelatedData = true)
        {
            if(!getRelatedData)
            {
                return await context.Vehicles.FindAsync(Id);
            }

            return await context.Vehicles
            .Include(vf => vf.VehicleFeatures)
            .ThenInclude(f => f.Feature)
            .Include(m => m.Model)
            .ThenInclude(mk => mk.Make)
            .SingleOrDefaultAsync(x => x.Id == Id);
        }
        public void AddVehicle(Vehicle vehicle)
        {
            context.Vehicles.Add(vehicle);
        }
        public void DeleteVehicle(Vehicle vehicle)
        {
            context.Vehicles.Remove(vehicle);
        }

        public async Task<Model> GetVehicleModel(int Id)
        {
           return await context.Models.FindAsync(Id);
        }

        public async Task<IEnumerable<Vehicle>> GetAllVehicles(Filter filter){
            var query =  context.Vehicles
            .Include(vf => vf.VehicleFeatures)
            .ThenInclude(f => f.Feature)
            .Include(m => m.Model)
            .ThenInclude(mk => mk.Make).AsQueryable();

            if(filter.MakeId.HasValue){
                query = query.Where(x => x.Model.MakeId == filter.MakeId);
            }

            if(filter.ModelId.HasValue){
                query = query.Where(x => x.Model.Id == filter.ModelId);
            }

            return await query.ToListAsync();
        }
    }
}