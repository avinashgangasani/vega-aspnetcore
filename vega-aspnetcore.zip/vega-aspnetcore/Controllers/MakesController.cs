using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vega_aspnetcore.Controllers.Resources;
using vega_aspnetcore.Core.Models;
using vega_aspnetcore.Persistence;

namespace vega_aspnetcore.Controllers
{
    public class MakesController : Controller
    {
        private readonly VegaDBContext context;
        private readonly IMapper mapper;

        public MakesController(VegaDBContext context, IMapper mapper)
        {
            this.mapper = mapper;
            this.context = context;
        }

        [HttpGet("/api/makes")]
        async public Task<IEnumerable<MakeResource>> Get()
        {
            var makes = await context.Makes.Include(x => x.Models).ToListAsync();

            return mapper.Map<List<Make>, List<MakeResource>>(makes);            
        }
    }
}