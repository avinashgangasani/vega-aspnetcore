using System.Collections.Generic;

namespace vega_aspnetcore.Controllers.Resources
{
    public class MakeResource : KeyValuePairResource
    {

        public ICollection<KeyValuePairResource> Models{ get; set; }

        public MakeResource()
        {
            this.Models = new List<KeyValuePairResource>();
        }
    }
}