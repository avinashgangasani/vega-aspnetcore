using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using vega_aspnetcore.Controllers.Resources;
using vega_aspnetcore.Core.Models;
using vega_aspnetcore.Persistence;
using vega_aspnetcore.Persistence.Core;

namespace vega_aspnetcore.Controllers
{
    [Route("/api/vehicles")]
    public class VehiclesController : Controller
    {
        private readonly IMapper mapper;
        private readonly IVehicleRepository repository;
        private readonly IUnitOfWork uow;
        public VehiclesController(IMapper mapper, IVehicleRepository repository, IUnitOfWork uow)
        {
            this.uow = uow;
            this.repository = repository;
            this.mapper = mapper;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateVehicle(int Id, [FromBody] SaveVehicleResource vehicleResource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var model = await repository.GetVehicleModel(vehicleResource.ModelId);
            if (model == null)
            {
                ModelState.AddModelError("ModelId", "Invalid model Id");
                return BadRequest(ModelState);
            }

            var vehicle = await repository.GetVehicleById(Id);

            mapper.Map<SaveVehicleResource, Vehicle>(vehicleResource, vehicle);
            vehicle.LastUpdated = System.DateTime.Now;

            await uow.CompletedAsync();

            var _vr = mapper.Map<Vehicle, VehicleResource>(vehicle);

            return Ok(_vr);
        }

        [HttpPost]
        public async Task<IActionResult> CreateVehicle([FromBody] SaveVehicleResource vehicleResource)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var model = await repository.GetVehicleModel(vehicleResource.ModelId);
            if (model == null)
            {
                ModelState.AddModelError("ModelId", "Invalid model Id");
                return BadRequest(ModelState);
            }

            var vehicle = mapper.Map<SaveVehicleResource, Vehicle>(vehicleResource);
            vehicle.LastUpdated = System.DateTime.Now;

            repository.AddVehicle(vehicle);
            await uow.CompletedAsync();

            vehicle = await repository.GetVehicleById(vehicle.Id);

            var _vr = mapper.Map<Vehicle, VehicleResource>(vehicle);

            return Ok(_vr);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVehicle(int Id)
        {
            var vehicle = await repository.GetVehicleById(Id, false);

            if (vehicle == null)
            {
                return NotFound(Id);
            }

            repository.DeleteVehicle(vehicle);
            await uow.CompletedAsync();

            return Ok(Id);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetVehicleById(int Id)
        {
            var vehicle = await repository.GetVehicleById(Id);

            if (vehicle == null)
            {
                return NotFound(Id);
            }

            var vehicleResource = mapper.Map<Vehicle, VehicleResource>(vehicle);
            return Ok(vehicleResource);
        }

        [HttpGet]
        public async Task<IEnumerable<VehicleResource>> GetAllVehicles(FilterResource filterResource)
        {
            var filter = mapper.Map<FilterResource, Filter>(filterResource);
            var vehicles = await repository.GetAllVehicles(filter);
            var vehicleResources = mapper.Map<IEnumerable<Vehicle>, IEnumerable<VehicleResource>>(vehicles);

            return vehicleResources;
        }
    }
}